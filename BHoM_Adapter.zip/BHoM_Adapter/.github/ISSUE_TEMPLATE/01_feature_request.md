---
name: Feature Request
about: Suggest ideas for new functionality, or enhancement of existing.
labels: "type:feature"

---
<!-- PLEASE ENSURE YOU REVIEW THE CONTENT OF EACH ISSUE CAREFULLY, INCLUDING SUBSEQUENT COMMENTS BY YOURSELF OR OTHERS. -->
<!-- IN PARTICULAR PLEASE ENSURE THAT SENSITIVE OR INAPPROPRIATE INFORMATION IS NOT UPLOADED -->

#### Description:
<!-- Describe your idea. Including details of the intended functionality, expected behaviour and desired inputs and outputs -->



