---
name: Question
about: Ask a question about any aspect of the BHoM code or toolkits. Equally do feel free to reach out on Slack with queries and for wider discussions. Link and open invite can be found on https://bhom.xyz
labels: "type:question"

---
<!-- PLEASE ENSURE YOU REVIEW THE CONTENT OF EACH ISSUE CAREFULLY, INCLUDING SUBSEQUENT COMMENTS BY YOURSELF OR OTHERS. -->
<!-- IN PARTICULAR PLEASE ENSURE THAT SENSITIVE OR INAPPROPRIATE INFORMATION IS NOT UPLOADED -->


<!-- If you would like to ask a question on Slack you can find a link and open invite on https://bhom.xyz -->